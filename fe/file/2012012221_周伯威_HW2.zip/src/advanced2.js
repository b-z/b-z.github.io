function search(stus, r)
{
	switch (typeof r)
	{
		case 'number':
		{
			var sum=0;
			var ans=[];
			for (var i in stus)
			{
				if (stus[i].age===r)
				{
					sum++;
					ans.push(stus[i]);
				}
			}
			return sum?ans:false;
		}
		case 'string':
		{
			var sum=0;
			var ans=[];
			for (var i in stus)
			{
				if (stus[i].name===r)
				{
					sum++;
					ans.push(stus[i]);
				}
			}
			return sum?ans[0]:false;
		}
		case 'object':
		{
			var sum=0;
			var ans=[];
			for (var i in stus)
			{
				var m=0;
				for (var j in r)
				{
					if (stus[i][j]!=r[j])
					{
						m=1;
					}
				}
				if (m==0)
				{
					sum++;
					ans.push(stus[i]);
				}
			}
			return sum?ans:false;
		}
	}
}

var input=[
{age:1,name:'abc',hometown:'de'},{age:2,name:'def',hometown:'de'},{age:1,name:'ghi',hometown:'ed'}
];

a1=search(input,1);
a2=search(input,'def');
a3=search(input,{age:1,hometown:'de'});
a4=search(input,{age:1});

[a1,a2,a3,a4];
